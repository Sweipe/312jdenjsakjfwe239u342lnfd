nodejs krävs
php med mysqli på krävs
sql server krävs

För att SQL-anrop ska funka på en annan dator så kan vissa saker behöva ändras:

'$servername' i 'sql.php', rad 2
'$username' i 'sql.php', rad 3		
'$password' i 'sql.php', rad 4