<?php
	echo 'why yes, this is rendered in php';
?>